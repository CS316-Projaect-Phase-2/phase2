"""
CS316 Project - Household energy consumption prediction and carbon footprint reduction
Dataset: UCI "Individual Household Electric Power Consumption" (household_power_consumption.txt)

Pipeline stages
  1. Load + clean (memory-optimised: selected columns, float32, ';' separator)
  2. Hourly aggregation + feature engineering (calendar, lag, rolling features)
  3. Exploratory plots
  4. Forecasting: Persistence & Linear Regression baselines vs Random Forest vs HistGradientBoosting
     (chronological train/validation/test split, TimeSeriesSplit tuning of the best model)
  5. Anomaly detection: residual z-score + Isolation Forest
  6. Carbon / cost estimates and data-driven recommendations

Usage:
    python energy_pipeline.py --data data/household_power_consumption.zip --out results
    # --data can be a local path (.zip or .txt) or a raw GitHub URL, as in the lecture slides
"""
import argparse
import json
import os
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # headless backend so the script runs on any machine
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor, IsolationForest, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import RandomizedSearchCV, TimeSeriesSplit

RANDOM_STATE = 42

# Compact, publication-style figures (IEEE single-column width is about 3.5 inches)
plt.rcParams.update({"font.size": 7, "axes.titlesize": 8, "legend.fontsize": 6.5, "axes.grid": True,
                     "grid.alpha": 0.25, "axes.spines.top": False, "axes.spines.right": False})

# Emission factor in kg CO2 per kWh. The data is from a French household, so a French grid
# value is used by default. Replace it with a value you can cite (e.g. from IEA / ADEME).
EMISSION_FACTOR_KG_PER_KWH = 0.05
PRICE_PER_KWH = 0.20  # currency units per kWh; adjust to the local tariff


# ----------------------------------------------------------------------------- 1. load
def load_data(path):
    """Read the raw file with only the needed columns and float32 to save memory.
    `path` can be a local path or a URL, and a .zip or .txt file: pd.read_csv handles all of them."""
    num_cols = ["Global_active_power", "Global_reactive_power", "Voltage", "Global_intensity",
                "Sub_metering_1", "Sub_metering_2", "Sub_metering_3"]
    dtypes = {c: "float32" for c in num_cols}
    raw = pd.read_csv(path, sep=";", na_values=["?", ""], dtype=dtypes,
                      usecols=["Date", "Time"] + num_cols, low_memory=False)
    raw["datetime"] = pd.to_datetime(raw["Date"] + " " + raw["Time"], format="%d/%m/%Y %H:%M:%S")
    raw = raw.drop(columns=["Date", "Time"]).set_index("datetime").sort_index()
    return raw


def clean_and_aggregate(raw):
    """Handle missing values and aggregate minute data to hourly energy (kWh)."""
    report = {"rows": int(len(raw)),
              "missing_rows": int(raw["Global_active_power"].isna().sum()),
              "missing_pct": round(float(raw["Global_active_power"].isna().mean() * 100), 3)}
    # Short gaps (<= 60 min) are interpolated; longer outages stay NaN and are dropped later.
    raw = raw.interpolate(method="time", limit=60)
    # Global_active_power is in kW (minute average) -> kWh per minute = kW / 60
    raw["energy_kwh"] = raw["Global_active_power"] / 60.0
    # Sub-meters are in Wh per minute -> convert to kWh
    for c in ["Sub_metering_1", "Sub_metering_2", "Sub_metering_3"]:
        raw[c] = raw[c] / 1000.0
    hourly = raw.resample("h").agg({
        "energy_kwh": "sum", "Global_reactive_power": "mean", "Voltage": "mean",
        "Global_intensity": "mean", "Sub_metering_1": "sum", "Sub_metering_2": "sum",
        "Sub_metering_3": "sum"}).astype("float32")
    # Hours with fewer than 45 valid minutes are unreliable -> mark missing
    valid_minutes = raw["Global_active_power"].notna().resample("h").sum()
    hourly.loc[valid_minutes < 45, :] = np.nan
    report["hourly_rows"] = int(len(hourly))
    report["hourly_missing"] = int(hourly["energy_kwh"].isna().sum())
    hourly = hourly.dropna()
    # Other rooms/appliances not covered by the three sub-meters (kitchen, laundry, water heater, rest)
    hourly["Sub_metering_rest"] = (hourly["energy_kwh"] - hourly[["Sub_metering_1", "Sub_metering_2",
                                                                  "Sub_metering_3"]].sum(axis=1)).clip(lower=0)
    return hourly, report


# ----------------------------------------------------------------------------- 2. features
def make_features(hourly):
    """Build a leakage-free supervised dataset: every feature uses information from the past only."""
    df = pd.DataFrame(index=hourly.index)
    df["target"] = hourly["energy_kwh"]
    idx = df.index
    df["hour"] = idx.hour
    df["dayofweek"] = idx.dayofweek
    df["month"] = idx.month
    df["is_weekend"] = (idx.dayofweek >= 5).astype("int8")
    # Cyclical encoding so that hour 23 and hour 0 are close to each other
    df["hour_sin"] = np.sin(2 * np.pi * idx.hour / 24)
    df["hour_cos"] = np.cos(2 * np.pi * idx.hour / 24)
    s = hourly["energy_kwh"]
    for lag in (1, 2, 3, 24, 48, 168):  # 168 h = same hour one week ago
        df[f"lag_{lag}"] = s.shift(lag)
    # shift(1) before rolling so the current hour is never part of its own feature
    df["roll_mean_24"] = s.shift(1).rolling(24).mean()
    df["roll_std_24"] = s.shift(1).rolling(24).std()
    df["roll_mean_168"] = s.shift(1).rolling(168).mean()
    df = df.astype("float32").dropna()
    return df


# ----------------------------------------------------------------------------- 3. EDA
def eda_plots(hourly, outdir):
    fig, ax = plt.subplots(figsize=(3.5, 2.3))
    hourly["energy_kwh"].resample("D").sum().plot(ax=ax, lw=0.8)
    ax.set_title("Daily household electricity consumption"); ax.set_ylabel("kWh/day"); ax.set_xlabel("")
    fig.tight_layout(); fig.savefig(f"{outdir}/fig1_daily.png", dpi=200); plt.close(fig)

    fig, axes = plt.subplots(2, 1, figsize=(3.5, 3.6))
    hourly.groupby(hourly.index.hour)["energy_kwh"].mean().plot(ax=axes[0], marker="o")
    axes[0].set_title("Average load by hour of day"); axes[0].set_xlabel("Hour"); axes[0].set_ylabel("kWh")
    hourly.groupby(hourly.index.month)["energy_kwh"].mean().plot(kind="bar", ax=axes[1])
    axes[1].set_title("Average load by month"); axes[1].set_xlabel("Month"); axes[1].set_ylabel("kWh")
    fig.tight_layout(); fig.savefig(f"{outdir}/fig2_profiles.png", dpi=200); plt.close(fig)

    shares = hourly[["Sub_metering_1", "Sub_metering_2", "Sub_metering_3", "Sub_metering_rest"]].sum()
    shares.index = ["Kitchen", "Laundry", "Water heater & A/C", "Other"]
    fig, ax = plt.subplots(figsize=(3.5, 2.5))
    ax.pie(shares, labels=shares.index, autopct="%1.0f%%", startangle=90)
    ax.set_title("Share of consumption by area")
    fig.tight_layout(); fig.savefig(f"{outdir}/fig3_shares.png", dpi=200); plt.close(fig)
    return (shares / shares.sum() * 100).round(1).to_dict()


# ----------------------------------------------------------------------------- 4. models
def metrics(y, p):
    return {"RMSE": float(np.sqrt(mean_squared_error(y, p))),
            "MAE": float(mean_absolute_error(y, p)),
            "R2": float(r2_score(y, p))}


def train_models(df, outdir):
    # Chronological split: 70% train, 15% validation, 15% test (no shuffling for time series)
    n = len(df); i1, i2 = int(n * 0.70), int(n * 0.85)
    train, val, test = df.iloc[:i1], df.iloc[i1:i2], df.iloc[i2:]
    feats = [c for c in df.columns if c != "target"]
    Xtr, ytr, Xva, yva, Xte, yte = (train[feats], train["target"], val[feats], val["target"],
                                    test[feats], test["target"])
    results, preds = {}, {}

    # Baseline 1: persistence - "same hour yesterday"
    preds["Persistence (lag 24h)"] = Xte["lag_24"].values
    # Baseline 2: linear regression
    lr = LinearRegression().fit(Xtr, ytr); preds["Linear Regression"] = lr.predict(Xte)
    # Random forest (limited size for speed / memory)
    rf = RandomForestRegressor(n_estimators=150, max_depth=14, min_samples_leaf=5, n_jobs=-1,
                               random_state=RANDOM_STATE).fit(Xtr, ytr)
    preds["Random Forest"] = rf.predict(Xte)
    # Gradient boosting with hyper-parameter search using TimeSeriesSplit (respects time order)
    search = RandomizedSearchCV(
        HistGradientBoostingRegressor(random_state=RANDOM_STATE),
        {"learning_rate": [0.03, 0.05, 0.1], "max_depth": [4, 6, 8, None],
         "max_leaf_nodes": [15, 31, 63], "l2_regularization": [0.0, 0.1, 1.0]},
        n_iter=10, cv=TimeSeriesSplit(n_splits=3), scoring="neg_root_mean_squared_error",
        random_state=RANDOM_STATE, n_jobs=-1).fit(pd.concat([Xtr, Xva]), pd.concat([ytr, yva]))
    gb = search.best_estimator_
    preds["Gradient Boosting (tuned)"] = gb.predict(Xte)

    for name, p in preds.items():
        results[name] = metrics(yte, p)
    best = min(results, key=lambda k: results[k]["RMSE"])

    # Prediction vs actual for one test week
    fig, ax = plt.subplots(figsize=(3.5, 2.3))
    wk = slice(0, 168)
    ax.plot(yte.index[wk], yte.values[wk], label="Actual", lw=1.2)
    ax.plot(yte.index[wk], preds[best][wk], label="Predicted (best model)", lw=1.2)
    ax.set_title("Hourly consumption: actual vs predicted (first test week)"); ax.set_ylabel("kWh")
    ax.xaxis.set_major_locator(mdates.DayLocator(interval=2)); ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    ax.legend(loc="upper right"); fig.tight_layout(); fig.savefig(f"{outdir}/fig4_pred.png", dpi=200); plt.close(fig)

    # Model comparison bar chart
    fig, ax = plt.subplots(figsize=(3.5, 2.2))
    pd.Series({k: v["RMSE"] for k, v in results.items()}).plot(kind="barh", ax=ax)
    ax.set_xlabel("RMSE (kWh)"); ax.set_title("Test RMSE by model")
    fig.tight_layout(); fig.savefig(f"{outdir}/fig5_models.png", dpi=200); plt.close(fig)

    # Feature importance by permutation on a test subsample (works for any model)
    from sklearn.inspection import permutation_importance
    sub = Xte.iloc[:: max(1, len(Xte) // 2000)]
    imp = permutation_importance(gb, sub, yte.loc[sub.index], n_repeats=5, random_state=RANDOM_STATE,
                                 scoring="neg_root_mean_squared_error")
    imp = pd.Series(imp.importances_mean, index=feats).sort_values()
    fig, ax = plt.subplots(figsize=(3.5, 2.7))
    imp.tail(10).plot(kind="barh", ax=ax); ax.set_title("Top feature importances (permutation)")
    fig.tight_layout(); fig.savefig(f"{outdir}/fig6_importance.png", dpi=200); plt.close(fig)

    test_pred = pd.Series(preds["Gradient Boosting (tuned)"], index=yte.index)
    return results, best, search.best_params_, yte, test_pred, imp.sort_values(ascending=False).head(10).round(4).to_dict()


# ----------------------------------------------------------------------------- 5. anomalies
def detect_anomalies(yte, pred, hourly, outdir):
    """Flag hours with unusually HIGH use: residual z-score > 3 and Isolation Forest agreement."""
    resid = yte - pred
    z = (resid - resid.mean()) / resid.std()
    feat = pd.DataFrame({"resid": resid, "actual": yte}).astype("float32")
    iso = IsolationForest(contamination=0.01, random_state=RANDOM_STATE).fit(feat)
    iso_flag = pd.Series(iso.predict(feat) == -1, index=feat.index)
    high = (z > 3)
    anomalies = yte[high & iso_flag]
    fig, ax = plt.subplots(figsize=(3.5, 2.3))
    ax.plot(yte.index, yte.values, lw=0.4, color="gray", label="Hourly use")
    ax.scatter(anomalies.index, anomalies.values, s=14, color="red", label="Abnormally high", zorder=3)
    ax.set_ylabel("kWh"); ax.set_title("Abnormal high-consumption hours (test period, 2010)")
    ax.xaxis.set_major_locator(mdates.MonthLocator()); ax.xaxis.set_major_formatter(mdates.DateFormatter("%b"))
    ax.legend(loc="upper left"); fig.tight_layout(); fig.savefig(f"{outdir}/fig7_anomalies.png", dpi=200); plt.close(fig)
    out = {"n_flagged": int(len(anomalies)), "share_of_hours_pct": round(len(anomalies) / len(yte) * 100, 2),
           "excess_kwh": float((resid[anomalies.index]).sum()),
           "test_days": float((yte.index[-1] - yte.index[0]).days + 1),
           "by_hour": anomalies.groupby(anomalies.index.hour).size().to_dict(),
           "by_month": anomalies.groupby(anomalies.index.month).size().to_dict()}
    return out


# ----------------------------------------------------------------------------- 6. carbon
def carbon_and_recommendations(hourly, anomalies, shares):
    years = (hourly.index[-1] - hourly.index[0]).days / 365.25
    annual_kwh = float(hourly["energy_kwh"].sum() / years)
    night = hourly[hourly.index.hour.isin([2, 3, 4, 5])]["energy_kwh"]
    standby_kwh_year = float(night.quantile(0.10) * 8760)  # low-percentile night load ~ always-on baseline
    peak_share = float(hourly[hourly.index.hour.isin(range(18, 22))]["energy_kwh"].sum()
                       / hourly["energy_kwh"].sum() * 100)
    scenarios = {  # simple what-if scenarios, assumptions stated in the report
        "Cut always-on standby load by 30%": standby_kwh_year * 0.30,
        "Reduce water-heater/A-C use by 10%": annual_kwh * shares["Water heater & A/C"] / 100 * 0.10,
        "Reduce kitchen+laundry use by 10%": annual_kwh * (shares["Kitchen"] + shares["Laundry"]) / 100 * 0.10,
        # excess energy in the test period, scaled to one year
        "Avoid abnormal high-use hours": anomalies["excess_kwh"] / anomalies["test_days"] * 365.25}
    table = {k: {"kWh_saved_per_year": round(v, 1),
                 "kgCO2_saved": round(v * EMISSION_FACTOR_KG_PER_KWH, 1),
                 "cost_saved": round(v * PRICE_PER_KWH, 1)} for k, v in scenarios.items()}
    return {"annual_kwh": round(annual_kwh, 1),
            "annual_kgCO2": round(annual_kwh * EMISSION_FACTOR_KG_PER_KWH, 1),
            "standby_kwh_year": round(standby_kwh_year, 1),
            "evening_peak_share_pct": round(peak_share, 1),
            "emission_factor": EMISSION_FACTOR_KG_PER_KWH, "price_per_kwh": PRICE_PER_KWH,
            "scenarios": table}


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(Path("data") / "household_power_consumption.zip"))
    ap.add_argument("--out", default="results")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    t0 = time.time()

    raw = load_data(a.data)
    print(f"Loaded {len(raw):,} minute rows, {raw.memory_usage(deep=True).sum() / 1e6:.0f} MB")
    hourly, clean_report = clean_and_aggregate(raw)
    del raw  # free memory: only the hourly table is needed from here on
    shares = eda_plots(hourly, a.out)
    df = make_features(hourly)
    results, best, params, yte, pred, imp = train_models(df, a.out)
    anomalies = detect_anomalies(yte, pred, hourly, a.out)
    carbon = carbon_and_recommendations(hourly, anomalies, shares)

    summary = {"cleaning": clean_report, "feature_rows": int(len(df)), "area_shares_pct": shares,
               "model_results": results, "best_model": best, "gb_best_params": {k: (v if v is not None else "None") for k, v in params.items()},
               "top_features": imp, "anomalies": anomalies, "carbon": carbon,
               "runtime_sec": round(time.time() - t0, 1)}
    with open(f"{a.out}/summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=float)
    pd.DataFrame(results).T.round(4).to_csv(f"{a.out}/model_metrics.csv")
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
