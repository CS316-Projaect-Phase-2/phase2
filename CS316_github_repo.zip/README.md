# Household Energy Consumption Prediction and Carbon Footprint Reduction

CS316 - Introduction to AI and Data Science (Term 261), Prince Sultan University
Instructor: Dr. Heyfa Ammar
Team: Fai bin Khanjar, Yara alzamel, Aljoharah altuwaijri

## What this project does
1. Cleans the UCI *Individual Household Electric Power Consumption* data (2,075,259 minute readings, Dec 2006 - Nov 2010).
2. Aggregates to hourly kWh and builds leakage-free time features (calendar, lags, rolling means).
3. Predicts next-hour household consumption with four models: persistence baseline, linear regression, random forest, tuned gradient boosting.
4. Flags abnormally high consumption hours (residual z-score > 3 AND Isolation Forest agreement).
5. Converts findings into carbon (kg CO2) and cost estimates for simple what-if recommendations (SDG 12 and 13).

## Setup
```bash
pip install -r requirements.txt
```
The dataset is stored in this repo as `data/household_power_consumption.zip` (20 MB; the unzipped .txt is 133 MB, which is above GitHub's 100 MB file limit). It comes from
https://archive.ics.uci.edu/dataset/235/individual+household+electric+power+consumption

Data is read the way we learned in the lectures, with `pd.read_csv` from a path or a URL. `read_csv` opens the zip directly, so no unzipping is needed:
```python
df = pd.read_csv("data/household_power_consumption.zip", sep=";", na_values=["?"])
df = pd.read_csv("https://raw.githubusercontent.com/<user>/<repo>/main/data/household_power_consumption.zip", sep=";", na_values=["?"])
```

## Run
```bash
python energy_pipeline.py --data data/household_power_consumption.zip --out results
```
`--data` also accepts the raw GitHub URL above. Runtime is about a minute. Outputs in `results/`: `fig1..fig7` (PNG), `model_metrics.csv`, `summary.json` (all numbers used in the report).

## Notebooks (Google Colab)
The project is also split into three notebooks, one per team member. Each one reads its input with `pd.read_csv` from the `data` folder and can be run on its own:

| Notebook | Owner | Reads | Saves |
|---|---|---|---|
| `notebooks/CS316_Part1_Yara_Data_and_Features.ipynb` | Yara | `household_power_consumption.zip` | `hourly.csv`, `features.csv` |
| `notebooks/CS316_Part2_Fai_Models.ipynb` | Fai | `features.csv` | `predictions.csv`, `model_metrics.csv` |
| `notebooks/CS316_Part3_Aljoharah_Anomalies_and_Carbon.ipynb` | Aljoharah | `hourly.csv`, `predictions.csv` | (results and figures) |

Open a notebook in Colab (File, Upload notebook) and replace `YOUR_USERNAME` and `YOUR_REPO` in the `urlprefix` cell with the real GitHub names. The three CSV files in `data/` were created by running Part 1 and Part 2, so Parts 2 and 3 can be started right away.

## Memory optimisation (graded item)
- Only needed columns are read; all numeric columns use `float32` (half the memory of `float64`).
- Minute data is deleted after hourly aggregation (`del raw`).
- Features are stored as `float32`; random forest is size-limited; `n_jobs=-1` for speed.

## Settings you may change
`EMISSION_FACTOR_KG_PER_KWH` and `PRICE_PER_KWH` at the top of `energy_pipeline.py`. The default factor is an approximate French grid value because the household is in France; cite your own source in the report.

## Use of AI
Parts of the code and documentation were drafted with Claude (Anthropic) and reviewed by the team.

## Main results (test set, last 15% of hours)
| Model | RMSE (kWh) | MAE (kWh) | R2 |
|---|---|---|---|
| Persistence (24 h) | 0.759 | 0.511 | -0.144 |
| Linear regression | 0.501 | 0.354 | 0.502 |
| Random forest | 0.472 | 0.326 | 0.557 |
| Gradient boosting (tuned) | 0.466 | 0.322 | 0.568 |

42 abnormal high-use hours were flagged (0.82% of the test period). Full numbers: `results/summary.json`; figures: `results/fig*.png`.
